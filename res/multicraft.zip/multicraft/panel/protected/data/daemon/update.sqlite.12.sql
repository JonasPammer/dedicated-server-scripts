alter table `server` add `crash_check` text not null default '';
