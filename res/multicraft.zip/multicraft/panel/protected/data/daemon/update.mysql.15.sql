alter table `server` add `domain` varchar(90) not null default '';
