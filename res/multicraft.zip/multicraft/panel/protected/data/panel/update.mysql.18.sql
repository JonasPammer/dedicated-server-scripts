alter table `server_config` add `user_add_ports` integer not null default 0;
