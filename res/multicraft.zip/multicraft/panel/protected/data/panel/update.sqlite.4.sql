alter table `user` add `global_role` text not null default 'none';
alter table `user` add `api_key` text not null default '';
